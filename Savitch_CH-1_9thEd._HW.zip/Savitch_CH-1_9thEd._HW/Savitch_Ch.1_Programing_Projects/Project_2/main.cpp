/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Jesus E. Moran Rivera
 *
 * Created on February 28, 2016, 4:29 PM
 */
//System Libraries
#include <iostream>
using namespace std;
//User libraries

//Global Constant

//Function Prototype

//Execution begins here
int main() 
{
//Declare Variables
    
//Map the input to the output
    
//Input values
    
//Output results
   cout << "*************************************************\n"
           "\n"
           "          C C C             S S S S          !!\n"
           "        C       C         S         S        !!\n"
           "       C                 S                   !!\n"
           "      C                   S                  !!\n"
           "      C                     S S S S          !!\n"
           "      C                            S         !!\n"
           "       C                            S        !!\n"
           "        C        C        S        S           \n"
           "          C C C             S S S S          00\n"
           "\n"
           "*************************************************\n";
   cout << "     Computer Science is Cool Stuff!!!\n";
   
   //End
   return 0;
}

