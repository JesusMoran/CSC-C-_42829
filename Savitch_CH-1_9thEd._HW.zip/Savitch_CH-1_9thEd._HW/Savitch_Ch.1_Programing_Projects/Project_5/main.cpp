/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Jesus E. Moran Riverside
 *
 * Created on February 28, 2016, 4:29 PM
 */
//System Libraries
#include <iostream>
using namespace std;
//User libraries

//Global Constant

//Function Prototype

//Execution begins here
int main() 
{
//Declare Variables
   int x; 
    
//Map the input to the output
    
//Input values
    
//Output results  
   cout << "Whats your favorite letter in C?"<<endl;
   cin >> x;
   
   cout<<x x x<<"\n";  
   cout<<x x<<"\n";
   cout<<x<<"\n";
   cout<<x<<"\n";
   cout<<x<<"\n";
   cout<<x<<"\n";
   cout<<x<<"\n";
   cout<<x x<<"\n";    
   cout<<x x x<<endl;
    //End
    cout << "Hope you enjoyed.\n";
    cout << "Good-bye.\n";
        
    return 0;
}


