/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Jesus E Moran Rivera
 *
 * Created on February 23, 2016, 8:27 PM
 */

#include <iostream>
using namespace std;

int main( )
 {
    int pods, peas, totalP;
    
    cout << "Press return after entering a number:\n";
    cout << "Enter the number of peas in a pod:\n";
    
    cin >> pods;
    
    cout << "Enter the number of peas in a pod:\n";
    cin >> peas;
    totalP = pods * pod;
    cout << "If you have ";
    cout << pods;
    cout << " pea pods\n";
    cout << "and ";
    cout << pod;
    cout << " peas in each pod, then \n";
    cout << "you have ";
    cout << totalP;
    cout << " peas in all the pods. \n";
   
    return 0;
}


